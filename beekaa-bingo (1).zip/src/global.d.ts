declare module 'ws';
